By default, the ThisIsMyFile.ini will be created in the folder %APPDATA%/ThisIsMyFile

For portable use, please create or copy in ThisIsMyFile working directory the ThisIsMyFile.ini.

Or run an portable_install!

Program Arguments (Command Line)
-?uninstall
-?install
-?portable_install


Rename:
ThisIsMyFile.exe 
ThisIsMyFile_Install.exe 
ThisIsMyFile_Portable_Install.exe
 