By default, the DesktopNoteOK.ini will be created in the folder %APPDATA%/DesktopNoteOK

For portable use, please create or copy in DesktopNoteOK working directory the DesktopNoteOK.ini.

Or run an portable_install!

Program Arguments (Command Line)
-?uninstall
-?install
-?portable_install


Rename:
DesktopNoteOK.exe 
DesktopNoteOK_Install.exe 
DesktopNoteOK_Portable_Install.exe

 