By default, the Delete.On.Reboot.ini will be created in the folder %APPDATA%/Delete.On.Reboot

For portable use, please create or copy in Delete.On.Reboot working directory the Delete.On.Reboot.ini.

Or run an portable_install!

Program Arguments (Command Line)
-?uninstall
-?install
-?portable_install


Rename:
Delete.On.Reboot.exe 
Delete.On.Reboot_Install.exe 
Delete.On.Reboot_Portable_Install.exe
 